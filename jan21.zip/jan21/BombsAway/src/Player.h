#pragma once
#ifndef __Player__
#define __Player__

#include "GameObject.h"
#include "TextureManager.h"

class Player : public GameObject {
public:
	Player();
	~Player();

	// See if a key is pressed down
	bool checkForKeystroke(SDL_Scancode c);
	
	// Draw the object
	void draw();

	// Update the object
	void update();

	// remove anything that needs to be deleted
	void clean();

    bool getRequest();
    void setRequest(bool request);

private:
	//bool m_bKeyDown; // True if a key is currently pressed down, otherwise false !!Might not need
	const Uint8* m_iKeystates; // Keyboard state container.
	const int m_iPlayerSpeed = 4;
    bool requestBomb = false;
};


#endif /* defined (__Player__) */