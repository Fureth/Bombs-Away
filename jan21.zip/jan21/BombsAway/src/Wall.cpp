#include "Game.h"
#include "Wall.h"

Wall::Wall()
{
    TheTextureManager::Instance()->load("../Assets/textures/wall.png", "wall", TheGame::Instance()->getRenderer());

    glm::vec2 size = TheTextureManager::Instance()->getTextureSize("wall");
    setWidth(size.x);
    setHeight(size.y);
    setIsColliding(false);
    setType(GameObjectType::WALL);
}

Wall::~Wall()
{
}

void Wall::draw()
{
    TheTextureManager::Instance()->draw("wall", getPosition().x, getPosition().y, TheGame::Instance()->getRenderer(), false);
}

void Wall::update()
{
    if (isDestroyed)
    {
        // If destroyed, remove the wall
    }
}

void Wall::clean()
{
}
