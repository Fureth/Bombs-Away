#pragma once
#include "Game.h"
#include <SDL.h>

const int MAP_WIDTH = 20;
const int MAP_HEIGHT = 20;

class Map
{
public:

    Map();
    ~Map();

    void LoadMap(int arr[MAP_WIDTH][MAP_HEIGHT]);
    void DrawMap();

private:

    SDL_Rect src, dest;
    SDL_Texture* wall;
    int currentMap[MAP_WIDTH][MAP_HEIGHT];


};