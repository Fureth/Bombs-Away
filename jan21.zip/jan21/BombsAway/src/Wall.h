#pragma once
#ifndef __Wall__
#define __Wall__

#include "GameObject.h"
#include "TextureManager.h"

class Wall : public GameObject {
public:
    Wall();
    ~Wall();

    // Draw the object
    void draw();

    // Update the object
    void update();

    // remove anything that needs to be deleted
    void clean();


private:
    bool isDestroyed = false;
    
};


#endif /* defined (__Wall__) */