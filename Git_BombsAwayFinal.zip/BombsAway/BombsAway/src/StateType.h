#pragma once
;enum StateType
{
	PAUSE,
	GAME,
	TITLE,
	OPTIONS,
	LOSE,
    WIN,
	TEST,
	NUM_OF_STATES
};