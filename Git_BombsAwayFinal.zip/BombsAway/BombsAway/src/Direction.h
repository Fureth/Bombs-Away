#pragma once

enum Direction
{
	NORTH,
	EAST,
	SOUTH,
	WEST,
	NUM_OF_DIRECTIONS
};