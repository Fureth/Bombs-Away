To start the game, go into "Debug" folder and launch the executable, "BombsAway_Executable"


WASD keys to move
Press space to place bomb
Hold space to throw bomb
P to pause
ESC to close game