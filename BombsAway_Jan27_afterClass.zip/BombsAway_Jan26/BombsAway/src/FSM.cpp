#include "FSM.h"
#include "Game.h"
#include <iostream>

// Begin State.
void State::render()
{
	SDL_RenderPresent(Game::Instance()->getRenderer());
}

void State::resume(){}

StateType State::getStateType()
{
	return m_stateType;
}

void State::setType(StateType newType)
{
	m_stateType = newType;
}

// End State.

// Begin PauseState.
PauseState::PauseState()
{
	std::cout << "Rendering Pause..." << std::endl;
	TheTextureManager::Instance()->load("../Assets/textures/Pause.png", "pause", TheGame::Instance()->getRenderer());
	setType(PAUSE);
}

void PauseState::enter()
{
	std::cout << "Entering Pause..." << std::endl;
	TheSoundManager::Instance()->pauseMusic();
}

void PauseState::update()
{
	if (Game::Instance()->checkForKeystroke(SDL_SCANCODE_R))
	{
		Game::Instance()->GetFSM().popState();
	}
}

void PauseState::render()
{
	TheTextureManager::Instance()->draw("pause", 320, 192, TheGame::Instance()->getRenderer(), false);
	//State::render();
}

void PauseState::exit()
{
	std::cout << "Exiting Pause..." << std::endl;
	TheSoundManager::Instance()->resumeMusic();
}
// End PauseState.

// Begin GameState.
GameState::GameState()
{
	std::cout << "Rendering Game..." << std::endl;
	TheTextureManager::Instance()->load("../Assets/textures/Game.png", "game", TheGame::Instance()->getRenderer());

	TheSoundManager::Instance()->load("../Assets/audio/backgroundMusic.WAV",
		"bgm", sound_type::SOUND_MUSIC);

	TheSoundManager::Instance()->playMusic("bgm", -1);
	
	setType(GAME);
}

void GameState::enter()
{
	std::cout << "Entering Game..." << std::endl;
}

void GameState::update()
{
	if (Game::Instance()->checkForKeystroke(SDL_SCANCODE_P))
	{
		Game::Instance()->GetFSM().pushState(new PauseState());
	}
	else if (Game::Instance()->checkForKeystroke(SDL_SCANCODE_X))
	{
		Game::Instance()->GetFSM().changeState(new TitleState());
	}
}

void GameState::render()
{
	TheTextureManager::Instance()->draw("game", 0, 0, TheGame::Instance()->getRenderer(), false);
}

void GameState::exit()
{
	std::cout << "Exiting Game..." << std::endl;
}

void GameState::resume()
{
	std::cout << "Resuming Game..." << std::endl;
}
// End GameState.

// Begin TitleState.
TitleState::TitleState()
{
	if (TheSoundManager::Instance()->musicPlaying())
	{
		TheSoundManager::Instance()->stopMusic();
	}
	std::cout << "Rendering Title..." << std::endl;
	TheTextureManager::Instance()->load("../Assets/textures/Title.png", "title", TheGame::Instance()->getRenderer());
	setType(TITLE);
}

void TitleState::enter()
{
	std::cout << "Entering Title..." << std::endl;
}

void TitleState::update()
{
	if (Game::Instance()->checkForKeystroke(SDL_SCANCODE_N))
	{
		Game::Instance()->GetFSM().changeState(new GameState());
	}
}

void TitleState::render()
{
	TheTextureManager::Instance()->draw("title", 250, 150, TheGame::Instance()->getRenderer(), false);
	//State::render();
}

void TitleState::exit()
{
	std::cout << "Exiting Title..." << std::endl;
}
// End TitleState.

// Begin FSM.
FSM::FSM() {}
FSM::~FSM() {}

void FSM::update()
{
	if (!m_vStates.empty())
	{
		m_vStates.back()->update(); // Invokes the Update of the current state.
	}
}

void FSM::render()
{
	if (!m_vStates.empty())
	{
		m_vStates.back()->render(); // Invokes the Render of the current state.
	}
}
void FSM::changeState(State* pState)
{
	if (!m_vStates.empty())
	{
		m_vStates.back()->exit(); // Invokes the Exit of the current state.
		delete m_vStates.back(); // Deallocates current state.
		m_vStates.back() = nullptr;
		m_vStates.pop_back();
	}
	//PushState(pState);
	pState->enter(); // Invoke the Enter of the NEW current state.
	m_vStates.push_back(pState); // Push the address of the NEW current state into the vector.
}

void FSM::pushState(State* pState) 
{
	pState->enter(); // Invoke the Enter of the NEW current state.
	m_vStates.push_back(pState); // Push the address of the NEW current state into the vector.
}

void FSM::popState() // e.g. PauseState to GameState.
{
	if (!m_vStates.empty())
	{
		m_vStates.back()->exit(); // Invokes the Exit of the current state.
		delete m_vStates.back(); // Deallocates current state.
		m_vStates.back() = nullptr;
		m_vStates.pop_back();
	}
	m_vStates.back()->resume();
}

void FSM::clean()
{
	while (!m_vStates.empty())
	{
		m_vStates.back()->exit(); // Invokes the Exit of the current state.
		delete m_vStates.back(); // Deallocates current state.
		m_vStates.back() = nullptr;
		m_vStates.pop_back();
	}
}

vector<State*>& FSM::getStates()
{
	return m_vStates;
}

// End FSM.
